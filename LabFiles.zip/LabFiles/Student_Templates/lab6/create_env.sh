#pyenv install 3.11.4 #Pre-installed
pyenv local 3.11.4
pyenv virtualenv 3.11.4 dynamodb
pyenv activate dynamodb
pip install boto3 awscli
