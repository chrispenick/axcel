import boto3

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name
table_name = 'SampleTable'

# Define the new items to add
items = [
    {
        'UserId': {'N': '3'},
        'UserName': {'S': 'Maya'},
        'UserAge': {'N': '19'}
    },
    {
        'UserId': {'N': '4'},
        'UserName': {'S': 'Marcus'},
        'UserAge': {'N': '25'}
    }
]

# Function to add an item to DynamoDB
def add_item(item):
    response = dynamodb.put_item(
        TableName=table_name,
        Item=item
    )
    return response

# Add the items to the table
for item in items:
    response = add_item(item)
    print(f"Added item: {item}")
    print("Response:", response)
