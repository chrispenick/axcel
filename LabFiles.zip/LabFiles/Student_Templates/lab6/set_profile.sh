#!/bin/bash
export AWS_PROFILE=wa3548
echo "setting AWS_PROFILE=${AWS_PROFILE}"