import boto3
import random
from faker import Faker

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name
table_name = 'SampleTable'

# Initialize Faker for generating fake data
faker = Faker()

# Known items with specific UserIds
known_items = [
    {'UserId': '20', 'UserName': 'Maya', 'UserAge': '30'},
    {'UserId': '40', 'UserName': 'Alain', 'UserAge': '25'},
    {'UserId': '60', 'UserName': 'Tino', 'UserAge': '35'},
    {'UserId': '80', 'UserName': 'Kumar', 'UserAge': '28'},
    {'UserId': '100', 'UserName': 'Evie', 'UserAge': '22'}
]

# Function to create a DynamoDB item
def create_item(user_id, user_name, user_age, source):
    return {
        'UserId': {'N': user_id},
        'UserName': {'S': user_name},
        'UserAge': {'N': user_age},
        'Source': {'S': source}
    }

# Function to create the DynamoDB table
def create_table():
    try:
        response = dynamodb.create_table(
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'UserId',
                    'KeyType': 'HASH'  # Partition key
                }
            ],
            AttributeDefinitions=[
                {
                    'AttributeName': 'UserId',
                    'AttributeType': 'N'
                }
            ],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            }
        )
        print("Table creation response:", response)
        print("Waiting for table to be created...")
        waiter = dynamodb.get_waiter('table_exists')
        waiter.wait(TableName=table_name)
        print("Table is ready!")
    except dynamodb.exceptions.ResourceInUseException:
        print("Table already exists. Skipping creation.")

# Function to delete the DynamoDB table
def delete_table():
    try:
        response = dynamodb.delete_table(TableName=table_name)
        print("Table deletion response:", response)
        print("Waiting for table to be deleted...")
        waiter = dynamodb.get_waiter('table_not_exists')
        waiter.wait(TableName=table_name)
        print("Table has been deleted!")
    except dynamodb.exceptions.ResourceNotFoundException:
        print("Table does not exist, no need to delete.")

# Function to add items to the table
def add_items():
    items_to_add = [create_item(item['UserId'], item['UserName'], item['UserAge'], 'add100') for item in known_items]

    generated_user_ids = set(item['UserId']['N'] for item in items_to_add)

    while len(items_to_add) < 100:
        user_id = str(random.randint(101, 1000))
        if user_id in generated_user_ids:
            continue
        
        user_name = faker.name()
        user_age = str(random.randint(18, 99))
        item = create_item(user_id, user_name, user_age, 'add100')
        items_to_add.append(item)
        generated_user_ids.add(user_id)

    for count, item in enumerate(items_to_add, start=1):
        try:
            response = dynamodb.put_item(TableName=table_name, Item=item)
            print(f"Added item {count}: {item}")
            print("Response:", response)
        except Exception as e:
            print(f"Failed to add item {count}: {item}")
            print("Error:", e)
    
    print(f"Successfully inserted {len(items_to_add)} records!")


# Main script logic
delete_table()
create_table()
add_items()
