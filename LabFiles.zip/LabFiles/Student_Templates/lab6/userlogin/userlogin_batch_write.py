import boto3
import json
import logging
from botocore.exceptions import ClientError

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# File handler for logging to a file
file_handler = logging.FileHandler('dynamodb_batch_write.log')
file_handler.setLevel(logging.INFO)
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)

# Stream handler for logging to console
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_formatter)

# Add handlers to the logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name and attributes
TABLE_NAME = 'UserLoginTable'
INPUT_FILE = 'dynamodb_records.json'

# Load records from JSON file
def load_records_from_json(filename):
    try:
        with open(filename, 'r') as file:
            records = json.load(file)
        # Ensure that records are in the correct format (list of dicts)
        if not isinstance(records, list):
            raise ValueError("The JSON file must contain a list of records.")
        logger.info(f"Records loaded successfully from {filename}.")
        return records
    except Exception as e:
        logger.error(f"Error loading records from JSON file: {e}")
        raise

# Function to format items correctly for DynamoDB
def format_item(item):
    return {key: value for key, value in item.items()}

# Function to batch write items to DynamoDB
def batch_write_items(items):
    max_batch_size = 25
    batch_counter = 0  # Initialize batch counter
    for i in range(0, len(items), max_batch_size):
        batch = items[i:i + max_batch_size]
        # Format items for DynamoDB
        formatted_batch = [{'PutRequest': {'Item': format_item(item)}} for item in batch]
        request_items = {'RequestItems': {TABLE_NAME: formatted_batch}}
        
        logger.info(f"Batch to be written: {formatted_batch}")

        try:
            response = dynamodb.batch_write_item(**request_items)
            logger.info(f"Batch write response: {response}")

            # Handle unprocessed items
            unprocessed_items = response.get('UnprocessedItems', {}).get(TABLE_NAME, [])
            retry_count = 0
            max_retries = 5

            while unprocessed_items and retry_count < max_retries:
                logger.warning("Unprocessed items found. Retrying...")
                retry_request_items = {'RequestItems': {TABLE_NAME: [{'PutRequest': {'Item': format_item(item)}} for item in unprocessed_items]}}
                try:
                    retry_response = dynamodb.batch_write_item(**retry_request_items)
                    unprocessed_items = retry_response.get('UnprocessedItems', {}).get(TABLE_NAME, [])
                    logger.info(f"Retry response: {retry_response}")
                except ClientError as e:
                    logger.error(f"Error retrying batch: {e}")
                    break
                retry_count += 1

            if retry_count == max_retries:
                logger.error("Maximum retries reached for unprocessed items.")
            
            batch_counter += 1  # Increment batch counter
            logger.info(f"*************************************************")
            logger.info(f"Batch {batch_counter} of {len(batch)} items written successfully!")
            logger.info(f"*************************************************")
        except ClientError as e:
            logger.error(f"Error writing batch: {e}")

    return batch_counter  # Return the total number of batches processed

# Main script logic
if __name__ == "__main__":
    try:
        records = load_records_from_json(INPUT_FILE)
        total_batches = batch_write_items(records)
        logger.info(f"====================================================")
        logger.info("All items have been successfully written to DynamoDB.")
        logger.info(f"Total batches processed: {total_batches}")  # Log total batches
        logger.info(f"====================================================")
    except Exception as e:
        logger.error(f"An error occurred: {e}")

