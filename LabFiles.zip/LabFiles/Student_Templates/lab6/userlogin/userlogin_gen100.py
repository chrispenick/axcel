import json
import uuid
import random
from faker import Faker
from datetime import datetime, timedelta

faker = Faker()
OUTPUT_FILE = 'dynamodb_records.json'

START_DATE = datetime(2020, 1, 1)
END_DATE = datetime(2024, 12, 31)
KNOWN_LOGIN_DATES = [
    '2024-01-15T12:00:00',
    '2024-03-22T09:30:00',
    '2024-05-10T14:45:00',
    '2024-06-30T16:20:00',
    '2024-12-01T11:00:00'
]

def generate_random_date(start, end):
    return (start + timedelta(days=random.randint(0, (end - start).days))).isoformat()

def select_known_dates(num_dates, date_list):
    return random.sample(date_list, num_dates)

known_users = [
    {'UserId': '20', 'UserName': 'Kumar', 'Source': 'userlogin_gen100.py', 'Email': 'kumar@example.com'},
    {'UserId': '40', 'UserName': 'Alain', 'Source': 'userlogin_gen100.py', 'Email': 'alain@example.com'},
    {'UserId': '60', 'UserName': 'Tino', 'Source': 'userlogin_gen100.py', 'Email': 'tino@example.com'},
    {'UserId': '80', 'UserName': 'Evie', 'Source': 'userlogin_gen100.py', 'Email': 'evie@example.com'},
    {'UserId': '100', 'UserName': 'Maya', 'Source': 'userlogin_gen100.py', 'Email': 'maya@example.com'}
]

login_pattern = {
    '20': 2,
    '40': 3,
    '60': 2,
    '80': 1,
    '100': 4
}

def create_registration_records(user, registration_dates, last_login_date):
    return [
        {
            'UserId': {'S': user['UserId']},
            'Email': {'S': user['Email']},
            'RegistrationDate': {'S': date},
            'UserName': {'S': user['UserName']},
            'Source': {'S': user['Source']},
            'LastLoginDate': {'S': last_login_date},
            'LoginEventId': {'S': str(uuid.uuid4())}  # Add LoginEventId
        }
        for date in registration_dates
    ]

def generate_known_user_records():
    records = []
    for user in known_users:
        user_id = user['UserId']
        num_logins = login_pattern.get(user_id, 1)
        selected_dates = select_known_dates(num_logins, KNOWN_LOGIN_DATES)
        
        last_login_date = max(selected_dates)  # Use the most recent login date
        
        records.extend(create_registration_records(user, selected_dates, last_login_date))
    
    return records

def create_fake_item(user_id):
    return {
        'UserId': {'S': user_id},
        'UserName': {'S': faker.name()},
        'Source': {'S': 'add100'},
        'Email': {'S': faker.email()},
        'RegistrationDate': {'S': generate_random_date(START_DATE, END_DATE)},
        'LastLoginDate': {'S': generate_random_date(START_DATE, END_DATE)},
        'LoginEventId': {'S': str(uuid.uuid4())}  # Add LoginEventId
    }

def generate_additional_records(existing_ids, num_records):
    records = []
    while len(records) < num_records:
        user_id = str(uuid.uuid4())
        if user_id in existing_ids:
            continue
        
        item = create_fake_item(user_id)
        records.append(item)
        existing_ids.add(user_id)
    
    return records

def generate_all_records():
    known_records = generate_known_user_records()
    known_ids = {record['UserId']['S'] for record in known_records}
    
    num_known_records = len(known_records)
    num_additional_records = 100 - num_known_records
    
    additional_records = generate_additional_records(known_ids, num_additional_records)
    
    return known_records + additional_records

def save_to_json(filename, records):
    try:
        with open(filename, 'w') as file:
            json.dump(records, file, indent=4)
        print(f"Records have been successfully generated and saved to {filename}")
    except IOError as e:
        print(f"Error saving to file {filename}: {e}")

if __name__ == "__main__":
    records = generate_all_records()
    save_to_json(OUTPUT_FILE, records)
    
    # Print the first few records for debugging
    print("Sample records generated:")
    print(json.dumps(records[:5], indent=4))
    
    # Optionally, print the total count of generated records
    print(f"Total records generated: {len(records)}")
