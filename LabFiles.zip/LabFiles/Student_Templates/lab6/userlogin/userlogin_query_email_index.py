import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'UserLoginTable'
EMAIL_INDEX_NAME = 'EmailIndex'

# Get DynamoDB table
table = dynamodb.Table(TABLE_NAME)

def query_by_email(email_prefix):
    try:
        # Query using the EmailIndex
        # BEGINS_WITH (only for partition keys, not GSIs)
        response = table.query(
            IndexName=EMAIL_INDEX_NAME,
            #KeyConditionExpression=Key('Email').begins_with(email_prefix)
            KeyConditionExpression=Key('Email').eq(email_prefix)
            
        )
        
        # Retrieve and print results
        items = response.get('Items', [])
        if not items:
            print("No items found for the given query.")
        else:
            print("Query results for EmailIndex:", items)
        
        return items
    except ClientError as e:
        print(f"Client error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

# Example query
if __name__ == "__main__":
    # Adjust the email_prefix as needed
    query_by_email('maya@example.com')
