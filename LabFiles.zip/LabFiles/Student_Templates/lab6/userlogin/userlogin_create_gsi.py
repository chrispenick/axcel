import boto3
from botocore.exceptions import ClientError

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name and index names
table_name = 'UserLoginTable'
email_index_name = 'EmailIndex'
last_login_date_index_name = 'LastLoginDateIndex'

# Function to add a Global Secondary Index (GSI) to an existing DynamoDB table
def add_gsi_to_table():
    try:
        # Update the table to add the GSI
        response = dynamodb.update_table(
            TableName=table_name,
            AttributeDefinitions=[
                {'AttributeName': 'Email', 'AttributeType': 'S'},  # String
                {'AttributeName': 'LastLoginDate', 'AttributeType': 'S'},  # String
                {'AttributeName': 'LoginEventId', 'AttributeType': 'S'}  # String
            ],
            GlobalSecondaryIndexUpdates=[
                {
                    'Create': {
                        'IndexName': email_index_name,
                        'KeySchema': [
                            {'AttributeName': 'Email', 'KeyType': 'HASH'},
                            {'AttributeName': 'LoginEventId', 'KeyType': 'RANGE'}
                        ],
                        'Projection': {
                            'ProjectionType': 'ALL'
                        },
                        'ProvisionedThroughput': {
                            'ReadCapacityUnits': 5,
                            'WriteCapacityUnits': 5
                        }
                    }
                }
            ]
        )
        print("Table update response:", response)
        print("Waiting for index to be added...")
        
        # Wait for the table to be updated
        waiter = dynamodb.get_waiter('table_exists')
        waiter.wait(TableName=table_name)
        print("Table updated with GSI!")

    except ClientError as e:
        print(f"Client error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

# Main script logic
if __name__ == "__main__":
    add_gsi_to_table()
