#!/bin/bash
aws dynamodb delete-table \
  --table-name UserLoginTable