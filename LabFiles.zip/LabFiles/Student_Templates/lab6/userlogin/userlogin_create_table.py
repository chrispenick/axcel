import boto3
from botocore.exceptions import ClientError

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name and index names
table_name = 'UserLoginTable'
email_index_name = 'EmailIndex'
last_login_date_index_name = 'LastLoginDateIndex'

# Function to create the DynamoDB table with GSI and LSI
def create_table_with_indexes():
    try:
        # Create the table with composite primary key, GSI, and LSI
        response = dynamodb.create_table(
            TableName=table_name,
            KeySchema=[
                {'AttributeName': 'LoginEventId', 'KeyType': 'HASH'},  # Partition key
            ],
            AttributeDefinitions=[
                {'AttributeName': 'LoginEventId', 'AttributeType': 'S'},  # String
            ],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            },
        )
        print("Table creation response:", response)
        print("Waiting for table to be created...")
        
        # Wait for the table to be created
        waiter = dynamodb.get_waiter('table_exists')
        waiter.wait(TableName=table_name)
        print("Table is ready!")
    
    except dynamodb.exceptions.ResourceInUseException:
        print("Table already exists. Skipping creation.")
    except ClientError as e:
        print(f"Client error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

# Main script logic
if __name__ == "__main__":
    create_table_with_indexes()
