import boto3

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table name
table_name = 'SampleTable'

# Define the UserIds to query
user_ids_to_query = ['20', '40', '60', '80', '100']

# Function to query specific records
def query_items(user_ids):
    # Construct the keys for batch_get_item request
    request_keys = [{'UserId': {'N': user_id}} for user_id in user_ids]
    
    # Initialize the batch_get_item request
    response = dynamodb.batch_get_item(
        RequestItems={
            table_name: {
                'Keys': request_keys
            }
        }
    )

    # Retrieve the items from the response
    items = response.get('Responses', {}).get(table_name, [])
    
    return items

# Main script logic
items = query_items(user_ids_to_query)
print('Queried the "constant/known" items:')
for item in items:
    print(item)
