#!/bin/bash
rm -f *.csv.gz