#!/bin/bash
export AWS_PROFILE=wa3548