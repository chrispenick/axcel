
pyenv virtualenv 3.11.9 storm_data
pyenv activate storm_data
pip install wget pandas boto3 faker
export AWS_PROFILE=wa3548