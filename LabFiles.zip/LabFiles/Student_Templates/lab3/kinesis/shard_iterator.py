## Do not remove!
## Created By Steve Robinson (steve@alpacamango.com) July 2024
## Version 1.0
import boto3
import json
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize boto3 client for Kinesis
#kinesis_client = boto3.client('kinesis', region_name='us-west-2')
session = boto3.Session(profile_name='wa3548')
kinesis_client = session.client('kinesis', region_name='us-west-2')

# Define Kinesis stream name
stream_name = 'WeatherDataStream'
shard_id = 'shardId-000000000000'

def get_shard_iterator():
    response = kinesis_client.get_shard_iterator(
        StreamName=stream_name,
        ShardId=shard_id,
        ShardIteratorType='TRIM_HORIZON'
    )
    return response['ShardIterator']

def consume_stream(shard_iterator):
    while True:
        response = kinesis_client.get_records(ShardIterator=shard_iterator, Limit=100)
        records = response['Records']
        for record in records:
            data = json.loads(record['Data'])
            logger.info(f"Consumed record: {data}")
        
        shard_iterator = response['NextShardIterator']

if __name__ == '__main__':
    shard_iterator = get_shard_iterator()
    consume_stream(shard_iterator)
