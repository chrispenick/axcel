## Do not remove!
## Created By Steve Robinson (steve@alpacamango.com) 17 July 2024
## Version 2.0
import boto3
import random
from faker import Faker
from decimal import Decimal
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Faker
fake = Faker()

# Set seed for reproducibility of the funny record positions
SEED = 12345
random.seed(SEED)

# Initialize boto3 client for Kinesis with a specific profile
session = boto3.Session(profile_name='wa3548')
kinesis_client = session.client('kinesis', region_name='us-west-2')

# Define Kinesis stream name
stream_name = 'StormEventsStream'

# Predefined funny records
funny_records = [
    {'name': 'Darth Vader', 'event': 'struck by lightsaber'},
    {'name': 'Bugs Bunny', 'event': 'chased by a chicken'},
    {'name': 'Daffy Duck', 'event': 'rescued by a cat'},
    {'name': 'Iron Man', 'event': 'attacked by a worm'},
    {'name': 'Superman', 'event': 'met with Yoda'}
]

# Predefined positions for the funny records
funny_positions = [5, 15, 25, 35, 45]

# Function to handle Decimal types
def decimal_to_str(value):
    if isinstance(value, Decimal):
        return str(value)
    return value

# CSV header
csv_header = ("YEARMONTH,EPISODE_ID,EVENT_ID,LOCATION_INDEX,RANGE,AZIMUTH,LOCATION,LATITUDE,LONGITUDE,LAT2,LON2,BEGIN_YEARMONTH,"
              "BEGIN_DAY,BEGIN_TIME,END_YEARMONTH,END_DAY,END_TIME,STATE,STATE_FIPS,YEAR,MONTH_NAME,EVENT_TYPE,CZ_TYPE,CZ_FIPS,"
              "CZ_NAME,WFO,BEGIN_DATE_TIME,CZ_TIMEZONE,END_DATE_TIME,INJURIES_DIRECT,INJURIES_INDIRECT,DEATHS_DIRECT,"
              "DEATHS_INDIRECT,DAMAGE_PROPERTY,DAMAGE_CROPS,SOURCE,MAGNITUDE,MAGNITUDE_TYPE,FLOOD_CAUSE,CATEGORY,TOR_F_SCALE,"
              "TOR_LENGTH,TOR_WIDTH,TOR_OTHER_WFO,TOR_OTHER_CZ_STATE,TOR_OTHER_CZ_FIPS,TOR_OTHER_CZ_NAME,BEGIN_RANGE,"
              "BEGIN_AZIMUTH,BEGIN_LOCATION,END_RANGE,END_AZIMUTH,END_LOCATION,BEGIN_LAT,BEGIN_LON,END_LAT,END_LON,"
              "EPISODE_NARRATIVE,EVENT_NARRATIVE,DATA_SOURCE,FAT_YEARMONTH,FAT_DAY,FAT_TIME,FATALITY_ID,FATALITY_TYPE,"
              "FATALITY_DATE,FATALITY_AGE,FATALITY_SEX,FATALITY_LOCATION,EVENT_YEARMONTH")

# Function to generate normal data
def generate_normal_data():
    return {
        'YEARMONTH': fake.date_this_year().strftime("%Y%m"),
        'EPISODE_ID': str(fake.uuid4()),
        'EVENT_ID': str(fake.uuid4()),
        'LOCATION_INDEX': str(random.randint(1, 10)),
        'RANGE': str(Decimal(random.uniform(0, 10))),
        'AZIMUTH': fake.word(),
        'LOCATION': fake.city(),
        'LATITUDE': str(Decimal(fake.latitude())),
        'LONGITUDE': str(Decimal(fake.longitude())),
        'LAT2': str(Decimal(fake.latitude())),
        'LON2': str(Decimal(fake.longitude())),
        'BEGIN_YEARMONTH': fake.date_this_year().strftime("%Y%m"),
        'BEGIN_DAY': str(random.randint(1, 28)),
        'BEGIN_TIME': str(random.randint(0, 2359)),
        'END_YEARMONTH': fake.date_this_year().strftime("%Y%m"),
        'END_DAY': str(random.randint(1, 28)),
        'END_TIME': str(random.randint(0, 2359)),
        'STATE': fake.state(),
        'STATE_FIPS': str(random.randint(1, 56)),
        'YEAR': str(int(fake.year())),
        'MONTH_NAME': fake.month_name(),
        'EVENT_TYPE': random.choice(['Funnel Cloud', 'Tornado', 'Thunderstorm Wind', 'Hail']),
        'CZ_TYPE': fake.word(),
        'CZ_FIPS': str(random.randint(1, 100)),
        'CZ_NAME': fake.city(),
        'WFO': fake.word(),
        'BEGIN_DATE_TIME': fake.date_time_this_year().isoformat(),
        'CZ_TIMEZONE': fake.timezone(),
        'END_DATE_TIME': fake.date_time_this_year().isoformat(),
        'INJURIES_DIRECT': str(random.randint(0, 10)),
        'INJURIES_INDIRECT': str(random.randint(0, 10)),
        'DEATHS_DIRECT': str(random.randint(0, 5)),
        'DEATHS_INDIRECT': str(random.randint(0, 5)),
        'DAMAGE_PROPERTY': f"{Decimal(random.uniform(0, 10)):.2f}K",
        'DAMAGE_CROPS': f"{Decimal(random.uniform(0, 10)):.2f}K",
        'SOURCE': fake.word(),
        'MAGNITUDE': str(Decimal(random.uniform(0, 100))),
        'MAGNITUDE_TYPE': fake.word(),
        'FLOOD_CAUSE': fake.word(),
        'CATEGORY': fake.word(),
        'TOR_F_SCALE': fake.word(),
        'TOR_LENGTH': str(Decimal(random.uniform(0, 10))),
        'TOR_WIDTH': str(Decimal(random.uniform(0, 1000))),
        'TOR_OTHER_WFO': fake.word(),
        'TOR_OTHER_CZ_STATE': fake.state(),
        'TOR_OTHER_CZ_FIPS': str(random.randint(1, 100)),
        'TOR_OTHER_CZ_NAME': fake.city(),
        'BEGIN_RANGE': str(Decimal(random.uniform(0, 10))),
        'BEGIN_AZIMUTH': fake.word(),
        'BEGIN_LOCATION': fake.city(),
        'END_RANGE': str(Decimal(random.uniform(0, 10))),
        'END_AZIMUTH': fake.word(),
        'END_LOCATION': fake.city(),
        'BEGIN_LAT': str(Decimal(fake.latitude())),
        'BEGIN_LON': str(Decimal(fake.longitude())),
        'END_LAT': str(Decimal(fake.latitude())),
        'END_LON': str(Decimal(fake.longitude())),
        'EPISODE_NARRATIVE': fake.sentence(),
        'EVENT_NARRATIVE': fake.sentence(),
        'DATA_SOURCE': 'STREAM',
        'FAT_YEARMONTH': fake.date_this_year().strftime("%Y%m"),
        'FAT_DAY': str(random.randint(1, 28)),
        'FAT_TIME': str(random.randint(0, 2359)),
        'FATALITY_ID': str(fake.uuid4()),
        'FATALITY_TYPE': fake.word(),
        'FATALITY_DATE': fake.date_time_this_year().isoformat(),
        'FATALITY_AGE': str(random.randint(0, 100)),
        'FATALITY_SEX': random.choice(['M', 'F']),
        'FATALITY_LOCATION': fake.word(),
        'EVENT_YEARMONTH': fake.date_this_year().strftime("%Y%m"),
    }

# Function to generate anomaly data
def generate_anomaly_data(index):
    data = generate_normal_data()
    funny_record = funny_records[index % len(funny_records)]
    data['EVENT_NARRATIVE'] = f"{funny_record['name']} {funny_record['event']}"
    return data

# Function to stream data to Kinesis
def stream_data(include_header=False):
    if include_header:
        try:
            response = kinesis_client.put_record(
                StreamName=stream_name,
                Data=(csv_header + '\n').encode('utf-8'),  # Encode header as bytes
                PartitionKey=str(fake.uuid4())  # Using a random UUID as the partition key
            )
            logger.info(f"Successfully streamed header with response: {response}")
        except Exception as e:
            logger.error(f"Failed to stream header: {e}")

    for i in range(100):  # Generate and stream 100 records
        try:
            if i in funny_positions:  # Check if current index is in the predefined funny positions
                data = generate_anomaly_data(funny_positions.index(i))
            else:
                data = generate_normal_data()
            
            csv_data = ','.join([str(decimal_to_str(data[key])) for key in data.keys()]) + '\n'
            
            response = kinesis_client.put_record(
                StreamName=stream_name,
                Data=csv_data.encode('utf-8'),  # Encode data as bytes
                PartitionKey=str(fake.uuid4())  # Using a random UUID as the partition key
            )
            logger.info(f"Successfully streamed data: {data} with response: {response}")
        except Exception as e:
            logger.error(f"Failed to stream data: {e}")

if __name__ == '__main__':
    stream_data(include_header=True)
