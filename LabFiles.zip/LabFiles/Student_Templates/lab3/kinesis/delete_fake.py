import boto3
import logging

# Constants
BUCKET_NAME = 'wa3548-180084736245-stormevents'
PREFIX = 'fake/'

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger()

def delete_objects_with_prefix(bucket_name, prefix):
    s3 = boto3.client('s3')
    paginator = s3.get_paginator('list_objects_v2')
    delete_us = dict(Objects=[])

    logger.info(f'Starting deletion of objects in bucket "{bucket_name}" with prefix "{prefix}"')

    for page in paginator.paginate(Bucket=bucket_name, Prefix=prefix):
        if 'Contents' in page:
            for obj in page['Contents']:
                delete_us['Objects'].append({'Key': obj['Key']})
                logger.info(f'Adding {obj["Key"]} to delete list')

                # Delete in batches of 1000 (S3 limit)
                if len(delete_us['Objects']) == 1000:
                    logger.info(f'Deleting batch of 1000 objects')
                    s3.delete_objects(Bucket=bucket_name, Delete=delete_us)
                    delete_us = dict(Objects=[])

    # Delete any remaining objects
    if delete_us['Objects']:
        logger.info(f'Deleting final batch of {len(delete_us["Objects"])} objects')
        s3.delete_objects(Bucket=bucket_name, Delete=delete_us)

    logger.info('Deletion process completed')

# Usage
delete_objects_with_prefix(BUCKET_NAME, PREFIX)
