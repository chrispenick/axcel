pyenv activate storm_data
export AWS_PROFILE=wa3548