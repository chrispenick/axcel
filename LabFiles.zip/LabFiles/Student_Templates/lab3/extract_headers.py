import os
import pandas as pd

FILES = [
    "StormEvents_locations-ftp_v1.0_d2020_c20240620.csv",
    "StormEvents_details-ftp_v1.0_d2020_c20240620.csv",
    "StormEvents_fatalities-ftp_v1.0_d2020_c20240620.csv"
]

def extract_headers(location_file, details_file, fatalities_file):
    # Extract headers from each file
    location_headers = pd.read_csv(location_file, nrows=0).columns.tolist()
    details_headers = pd.read_csv(details_file, nrows=0).columns.tolist()
    fatalities_headers = pd.read_csv(fatalities_file, nrows=0).columns.tolist()
    
    # Save headers to CSV files
    pd.DataFrame(location_headers, columns=['location_header']).to_csv('location_headers.csv', index=False)
    pd.DataFrame(details_headers, columns=['details_header']).to_csv('details_headers.csv', index=False)
    pd.DataFrame(fatalities_headers, columns=['fatalities_header']).to_csv('fatalities_headers.csv', index=False)
    
    print("Headers extracted and saved as location_headers.csv, details_headers.csv, and fatalities_headers.csv")

def main():
    location_file = FILES[0]
    details_file = FILES[1]
    fatalities_file = FILES[2]
    extract_headers(location_file, details_file, fatalities_file)

if __name__ == '__main__':
    main()
