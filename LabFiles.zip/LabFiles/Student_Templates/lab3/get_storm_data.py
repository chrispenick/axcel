## Do not remove!
## Created By Steve Robinson (steve@alpacamango.com) July 2024
## Version 1.0
## Data Source: https://www.ncei.noaa.gov/pub/data/swdi/stormevents/
## Note for emergencies the data has been pre-downloaded, so students can copy the data from the /home/wasadmin/Student_Templates/lab3 folder.

import os
import pandas as pd
import wget
import gzip
import shutil
from urllib.error import HTTPError

# Events Locations
# https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/StormEvents_locations-ftp_v1.0_d2020_c20240620.csv.gz
# Events Details
# https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/StormEvents_details-ftp_v1.0_d2020_c20240620.csv.gz
# Events Fatalities
# https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/StormEvents_fatalities-ftp_v1.0_d2020_c20240620.csv.gz

BASE_URL = "https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/"

# Define file names
FILES = [
    "StormEvents_locations-ftp_v1.0_d2020_c20240620.csv.gz",
    "StormEvents_details-ftp_v1.0_d2020_c20240620.csv.gz",
    "StormEvents_fatalities-ftp_v1.0_d2020_c20240620.csv.gz"
]

# Function to download files
def download_files(base_url, filenames):
    print(f"base_url={BASE_URL}")
    for filename in filenames:
        if not os.path.exists(filename):
            url = base_url + filename
            print(f"url={url}")
            try:
                print(f"Downloading {filename}...")
                wget.download(url, filename)
            except HTTPError as e:
                if e.code == 404:
                    print(f"Error 404: {url} not found.")
                    return False
                else:
                    print(f"Error downloading {url}: {e}")
                    return False
        else:
            print(f"{filename} already exists. Skipping download.")
    return True

# Function to extract gzip files
def extract_files(filenames):
    for filename in filenames:
        print(f"Extracting: {filename}")
        if filename.endswith('.gz'):  # Corrected the typo here
            extracted_filename = filename[:-3]
            if not os.path.exists(extracted_filename):
                with gzip.open(filename, 'rb') as f_in:
                    with open(extracted_filename, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
                print(f"Extracted {filename}")
            else:
                print(f"{extracted_filename} already exists. Skipping extraction.")

# Main function to orchestrate the steps
def main():
    # Download files
    if not download_files(BASE_URL, FILES):
        print("Error: One or more files could not be downloaded. Exiting.")
        return
    
    # Extract files
    extract_files(FILES)

# Run the main function
if __name__ == '__main__':
    main()

