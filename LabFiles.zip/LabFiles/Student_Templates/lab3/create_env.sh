#pyenv install 3.11.4 # now pre-installed
pyenv local 3.11.4
pyenv virtualenv 3.11.4 storm_data
pyenv activate storm_data
pip install wget pandas boto3 faker
export AWS_PROFILE=wa3548
