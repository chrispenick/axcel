#!/bin/bash

# Variables
BUCKET_NAME="wa3548-180084736245-stormevents"
PREFIX="real"
FILES=(
    "StormEvents_details-ftp_v1.0_d2020_c20240620.csv"
    "StormEvents_fatalities-ftp_v1.0_d2020_c20240620.csv"
    "StormEvents_locations-ftp_v1.0_d2020_c20240620.csv"
) # List of files to upload

# Loop through the files and upload each one to the specified prefix
for FILE in "${FILES[@]}"; do
  if [[ -f "$FILE" ]]; then
    aws s3 cp "$FILE" "s3://$BUCKET_NAME/$PREFIX/$FILE"
    if [[ $? -eq 0 ]]; then
      echo "Successfully uploaded $FILE to s3://$BUCKET_NAME/$PREFIX/"
    else
      echo "Failed to upload $FILE"
    fi
  else
    echo "File $FILE does not exist"
  fi
done
