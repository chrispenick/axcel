import os
import pandas as pd
import csv

# Do NOT edit names!
FILES = [
    "StormEvents_locations-ftp_v1.0_d2020_c20240620.csv",
    "StormEvents_details-ftp_v1.0_d2020_c20240620.csv",
    "StormEvents_fatalities-ftp_v1.0_d2020_c20240620.csv"
]

OUTPUT_FILE = 'Combined_StormEvents.csv'

# Function to load and combine data
def combine_data(location_file, details_file, fatalities_file):
    print(f"Merging files, using data frames ...")
    # Load the CSV files into DataFrames
    location_df = pd.read_csv(location_file)
    details_df = pd.read_csv(details_file)
    fatalities_df = pd.read_csv(fatalities_file)
    
    # Print column names to debug
    print("Location DataFrame columns:", location_df.columns)
    print("Details DataFrame columns:", details_df.columns)
    print("Fatalities DataFrame columns:", fatalities_df.columns)
    
    # Ensure column names are stripped of any extra spaces
    location_df.columns = location_df.columns.str.strip()
    details_df.columns = details_df.columns.str.strip()
    fatalities_df.columns = fatalities_df.columns.str.strip()
    
    # Check if the necessary columns are present in location and details DataFrames
    for df, name in zip([location_df, details_df], ['Location', 'Details']):
        for col in ['EPISODE_ID', 'EVENT_ID']:
            if col not in df.columns:
                raise KeyError(f"Column {col} not found in {name} DataFrame")
    
    # Check if the necessary column is present in fatalities DataFrame
    if 'EVENT_ID' not in fatalities_df.columns:
        raise KeyError("Column EVENT_ID not found in Fatalities DataFrame")
    
    # Merge location and detailed event data on EPISODE_ID and EVENT_ID
    combined_df = pd.merge(location_df, details_df, on=['EPISODE_ID', 'EVENT_ID'], how='left')
    
    # Merge fatalities data on EVENT_ID
    combined_df = pd.merge(combined_df, fatalities_df, on='EVENT_ID', how='left')
    print(f"Completed merging of files")
    return combined_df

# Function to save combined data to CSV
def save_combined_data(combined_df, output_file):
    combined_df.to_csv(output_file, index=False, quotechar='"', quoting=csv.QUOTE_ALL)

# Main function to orchestrate the steps
def main():
    # Combine data
    location_file = FILES[0]
    details_file = FILES[1]
    fatalities_file = FILES[2]
    
    combined_df = combine_data(location_file, details_file, fatalities_file)
    
    # Save combined data to CSV
    save_combined_data(combined_df, OUTPUT_FILE)
    
    print(f"Combined data saved to {OUTPUT_FILE}")

# Run the main function
if __name__ == '__main__':
    main()
