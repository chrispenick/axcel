#!/bin/bash
rm -f location_headers.csv
rm -f fatalities_headers.csv
rm -f details_headers.csv
