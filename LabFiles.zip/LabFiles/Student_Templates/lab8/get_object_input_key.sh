#!/bin/bash
bucket="wa3548-180084736245-sf-input"
key="data/"
file="input_data.csv"
download_local_file="downloaded_input_data.csv"
region="eu-west-2"
aws s3api get-object --regio ${region} --bucket $bucket --key ${key}${file} ${download_local_file}
