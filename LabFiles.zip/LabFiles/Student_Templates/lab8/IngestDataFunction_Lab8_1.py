# IngestDataFunction_Lab8_1.py
# This function gets data from input file and prints the data
# Do not remove comments!
import json
import boto3
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    
     # Log the received event
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Extract details from the event
    input_bucket = event.get('input_bucket')
    input_key = event.get('input_key')


    # Check for required parameters
    missing_params = []
    if not input_bucket:
        missing_params.append('input_bucket')
    if not input_key:
        missing_params.append('input_key')


    if missing_params:
        logger.error(f"Missing parameters: {', '.join(missing_params)}")
        raise Exception(f"Error: Missing parameters: {', '.join(missing_params)}")
    
    logger.info(f"input_bucket: {input_bucket}")
    logger.info(f"input_key: {input_key}")
    
    try:
        # Get object from S3
        logger.info(f"Getting {input_key} from {input_bucket}")
        response = s3.get_object(Bucket=input_bucket, Key=input_key)
        data = response['Body'].read().decode('utf-8')
        
        # Log the data received
        logger.info("Data:")
        logger.info(data)
          
    except Exception as e:
        logger.error(f"[INPUT] Unexpected error: {e}")
        raise Exception("Error: An unexpected error occurred during ingestion.")
    
    body=f"Data ingested from input bucket: {input_bucket} successfully!"
    return {
        'statusCode': 200,
        'body': json.dumps(body)
    }
        
    
    
