#!/bin/bash
aws s3 ls s3://wa3548-180084736245-sf-input/data/
aws s3 ls s3://wa3548-180084736245-sf-input/data/input_data.csv
aws s3api get-object --bucket wa3548-180084736245-sf-input --key data/input_data.csv /tmp/test_file.csv
