import boto3

def get_account_id():
    """Retrieve the AWS account ID using STS."""
    sts_client = boto3.client('sts')
    return sts_client.get_caller_identity().get('Account')

def list_s3_buckets_with_suffix(suffix):
    """List all S3 buckets that match the given suffix."""
    s3_client = boto3.client('s3')
    matching_buckets = []
    
    try:
        response = s3_client.list_buckets()
        for bucket in response['Buckets']:
            if bucket['Name'].endswith(suffix):
                matching_buckets.append(bucket['Name'])
    except Exception as e:
        print(f'Error listing buckets: {e}')
    
    return matching_buckets

def empty_s3_bucket(bucket_name):
    """Delete all objects in an S3 bucket."""
    s3_client = boto3.client('s3')
    try:
        # List and delete all objects in the bucket
        response = s3_client.list_objects_v2(Bucket=bucket_name)
        if 'Contents' in response:
            for obj in response['Contents']:
                s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
                print(f'Deleted object {obj["Key"]} from bucket {bucket_name}')
    
    except Exception as e:
        print(f'Error emptying bucket "{bucket_name}": {e}')

if __name__ == "__main__":
    # Retrieve the AWS account ID
    account_id = get_account_id()

    # Suffix to match bucket names
    BUCKET_SUFFIX = '-redshift'

    # Find and process buckets with the matching suffix
    buckets_to_empty = list_s3_buckets_with_suffix(BUCKET_SUFFIX)
    
    for bucket_name in buckets_to_empty:
        print(f'Emptying bucket: {bucket_name}')
        empty_s3_bucket(bucket_name)
