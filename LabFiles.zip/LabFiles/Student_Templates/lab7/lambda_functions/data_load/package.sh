rm -Rf packages
pip install -r requirements.txt -t packages
cp lambda_function.py packages/
cd packages
zip -r ../lambda_function_payload.zip .
cd ..
rm -Rf packages