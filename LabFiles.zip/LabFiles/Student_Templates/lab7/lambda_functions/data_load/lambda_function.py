import json
import boto3
import csv
import pg8000
import os
import logging
from datetime import datetime

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# MM/DD/YYYY %I:%M:%S %p (format found in source data)
# YYYY-MM-DD %H:%M:%S (format required for redshift)
def parse_datetime(date_str):
    #logger.info(f"date_str={date_str}") #DO NOT REMOVE!
    try:
        return datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
    except ValueError:
        try:
            return datetime.strptime(date_str, '%m/%d/%Y %I:%M:%S %p')  # Existing format with AM/PM
        except ValueError:
            raise ValueError(f"time data '{date_str}' does not match any supported format")

def lambda_handler(event, context):
    logger.info("Received event: " + json.dumps(event, indent=2))

    # Retrieve S3 bucket and object key from the event
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        logger.info(f"Processing file: {bucket}/{key}")
    except Exception as e:
        logger.error(f"Error parsing event: {e}")
        return {
            'statusCode': 400,
            'body': json.dumps('Error parsing event: ' + str(e))
        }

    # Download the file from S3
    s3 = boto3.client('s3')
    local_file_path = '/tmp/data_chunk.csv'
    try:
        s3.download_file(bucket, key, local_file_path)
        file_size = os.path.getsize(local_file_path)
        logger.info(f"File downloaded successfully. File size: {file_size} bytes")
    except Exception as e:
        logger.error(f"Error downloading file from S3: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error downloading file from S3: ' + str(e))
        }

    # Extract Redshift connection details from environment variables
    try:
        database = os.environ['REDSHIFT_DB']
        user = os.environ['REDSHIFT_USER']
        password = os.environ['REDSHIFT_PASSWORD']
        host = os.environ['REDSHIFT_HOST']
        logger.info(f"Database: {database}")
        logger.info(f"User: {user}")
        logger.info(f"Host: {host}")
    except KeyError as e:
        logger.error(f"Environment variable {e} not set")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Environment variable {e} not set")
        }

    # Connect to Redshift
    try:
        conn = pg8000.connect(
            database=database,
            user=user,
            password=password,
            host=host,
            port=5439
        )
        logger.info("Connected to Redshift successfully")
    except pg8000.InterfaceError as e:
        logger.error(f"Connection error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Connection error: ' + str(e))
        }
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Unexpected error: ' + str(e))
        }

    # Read and process CSV file
    try:
        logger.info("Processing CSV file ...")
        cur = conn.cursor()
        processed_row_count = 0
        last_row = None

        with open(local_file_path, 'r') as f:
            reader = csv.reader(f)
            header = next(reader, None)  # Read header row
            
            if header is None:
                logger.warning("CSV file is empty, no data processed.")
                return {
                    'statusCode': 200,
                    'body': json.dumps('CSV file is empty, no data processed.')
                }

            # Check if there are any rows to process
            rows = list(reader)
            total_rows = len(rows)
            if total_rows == 0:
                logger.warning("CSV file contains only the header row, no data to process.")
                return {
                    'statusCode': 200,
                    'body': json.dumps('CSV file contains only the header row, no data processed.')
                }

            logger.info(f"CSV header: {header}")
            logger.info(f"Total rows in file: {total_rows}")
            
            for row in rows:
                # Data type validation and conversion
                try:
                    row = [
                        int(float(row[0])),  # VendorID
                        parse_datetime(row[1]),  # tpep_pickup_datetime
                        parse_datetime(row[2]),  # tpep_dropoff_datetime
                        int(float(row[3])),  # passenger_count
                        float(row[4]),  # trip_distance
                        int(float(row[5])),  # RatecodeID
                        row[6],  # store_and_fwd_flag
                        int(row[7]),  # PULocationID
                        int(row[8]),  # DOLocationID
                        int(float(row[9])),  # payment_type
                        float(row[10]),  # fare_amount
                        float(row[11]),  # extra
                        float(row[12]),  # mta_tax
                        float(row[13]),  # tip_amount
                        float(row[14]),  # tolls_amount
                        float(row[15]),  # improvement_surcharge
                        float(row[16]),  # total_amount
                        float(row[17])  # congestion_surcharge
                    ]
                    last_row = row
                except ValueError as ve:
                    logger.error(f"ValueError: {ve} in row: {row}")
                    continue  # Skip this row

                #logger.info(f"Inserting row: {row}") # DO NOT REMOVE!
                cur.execute(
                    """
                    INSERT INTO yellow_taxi_data (
                        VendorID, tpep_pickup_datetime, tpep_dropoff_datetime, passenger_count, trip_distance,
                        RatecodeID, store_and_fwd_flag, PULocationID, DOLocationID, payment_type, fare_amount,
                        extra, mta_tax, tip_amount, tolls_amount, improvement_surcharge, total_amount, congestion_surcharge
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
                    )
                    """,
                    row
                )
                processed_row_count += 1

        conn.commit()
        cur.close()
        conn.close()
        logger.info(f"Successfully processed file: {bucket}/{key}")
        logger.info(f"Total rows processed: {processed_row_count}")
        if last_row:
            logger.info(f"Last row processed: {last_row}")

        return {
            'statusCode': 200,
            'body': json.dumps(f'Processed file: {key}, total rows processed: {processed_row_count}, total rows in file: {total_rows}')
        }
    except Exception as e:
        logger.error(f"Error processing file: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error processing file: ' + str(e))
        }
