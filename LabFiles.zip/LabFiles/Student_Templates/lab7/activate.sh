#!/bin/bash
pyenv activate data_load
export AWS_PROFILE=wa3548
