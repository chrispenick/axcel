#!/bin/bash
export AWS_PROFILE=wa3548               
# Replace <vpc-id> with your actual VPC ID
export vpc_id=$(aws ec2 describe-vpcs --query "Vpcs[?IsDefault==\`true\`].VpcId" --output text)
echo "vpc_id=${vpc_id}"
# List all VPC endpoint IDs
aws ec2 describe-vpc-endpoints --filters "Name=vpc-id,Values=$vpc_id" --output json
export endpoint_ids=$(aws ec2 describe-vpc-endpoints --filters "Name=vpc-id,Values=$vpc_id" --query "VpcEndpoints[*].VpcEndpointId" --output text)
echo "endpoint_ids=${endpoint_ids}"
# Delete each VPC endpoint
for endpoint_id in $endpoint_ids; do
  echo "Deleting VPC Endpoint: $endpoint_id"
  aws ec2 delete-vpc-endpoints --vpc-endpoint-ids $endpoint_id
done
