export AWS_PROFILE=wa3548               
export TF_VAR_AWS_PROFILE="$AWS_PROFILE"
