pyenv local 3.11.4
pyenv virtualenv 3.11.4 data_load
pyenv activate data_load
pip install pandas
export AWS_PROFILE=wa3548               
export TF_VAR_AWS_PROFILE="$AWS_PROFILE"
