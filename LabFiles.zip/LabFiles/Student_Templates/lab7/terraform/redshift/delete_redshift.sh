#!/bin/bash
FINAL_SNAPSHOT_ID="final-snapshot-20240713" #REPLACE with your actual final-cluster-snapshot-identifier
aws redshift delete-cluster \
    --cluster-identifier wa2548cluster1 \
    --final-cluster-snapshot-identifier ${FINAL_SNAPSHOT_ID}
