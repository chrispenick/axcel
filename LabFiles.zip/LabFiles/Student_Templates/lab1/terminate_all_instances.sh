#!/bin/bash

# Retrieve all running instance IDs
instance_ids=$(aws ec2 describe-instances \
    --query "Reservations[*].Instances[*].InstanceId" \
    --filters "Name=instance-state-name,Values=running,stopped" \
    --output text)

# Terminate all running instances
if [ -n "$instance_ids" ]; then
    # Convert instance_ids to an array to handle spaces correctly
    instance_ids_array=($instance_ids)
    aws ec2 terminate-instances --instance-ids "${instance_ids_array[@]}"
    echo "Terminating instances: ${instance_ids_array[@]}"
else
    echo "No running/stopped instances to terminate."
fi
