#!/bin/bash

# Setup profile
export AWS_PROFILE="wa3548"

# Variables
KEY_NAME="wa3548-keypair" # Change this to your desired key pair name
KEY_PATH="$HOME/.ssh/${KEY_NAME}.pem"

# Delete the EC2 key pair
echo "Deleting EC2 key pair: ${KEY_NAME}"
aws ec2 delete-key-pair --key-name ${KEY_NAME}

# Verify the key pair deletion
if [ $? -eq 0 ]; then
    echo "Key pair ${KEY_NAME} deleted successfully."
else
    echo "Failed to delete the key pair ${KEY_NAME}."
fi

# Optionally, remove the local key file if it exists
if [ -f ${KEY_PATH} ]; then
    echo "Removing local key file: ${KEY_PATH}"
    rm -f ${KEY_PATH}
    echo "Local key file removed."
else
    echo "Local key file not found: ${KEY_PATH}"
fi

# Create a new EC2 key pair
echo "Creating a new EC2 key pair: ${KEY_NAME}"
aws ec2 create-key-pair --key-name ${KEY_NAME} --query 'KeyMaterial' --output text > ${KEY_PATH}

# Set the correct permissions for the key file
chmod 400 ${KEY_PATH}

# Verify the key pair creation
if [ -f ${KEY_PATH} ]; then
    echo "Key pair created and saved to ${KEY_PATH}"
else
    echo "Failed to create the key pair."
fi
