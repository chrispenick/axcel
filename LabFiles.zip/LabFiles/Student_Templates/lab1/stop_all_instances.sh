#!/bin/bash
# Retrieve all running instance IDs
instance_ids=$(aws ec2 describe-instances \
    --query "Reservations[*].Instances[*].InstanceId" \
    --filters "Name=instance-state-name,Values=running" \
    --output text)

# Stop all running instances
if [ -n "$instance_ids" ]; then
    aws ec2 stop-instances --instance-ids $instance_ids
    echo "Stopping instances: $instance_ids"
else
    echo "No running instances to stop."
fi