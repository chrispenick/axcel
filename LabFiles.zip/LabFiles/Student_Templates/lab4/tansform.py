import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

DATABASE_NAME = "storm-events-glue-db"
REAL_TABLE_NAME = "real"
FAKE_TABLE_NAME = "fake"
ACCOUNT_ID = "YOUR_ACCOUNT_ID"  # Replace with your AWS Account Id

args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Function to process a table and get the counts
def process_table(table_name):
    dyf = glueContext.create_dynamic_frame.from_catalog(database=DATABASE_NAME, table_name=table_name)
    df = dyf.toDF()
    
    # Print schema to understand the structure of deaths_direct and deaths_indirect
    df.printSchema()

    # Cast columns to appropriate types
    df = df.withColumn("deaths_direct_int", col("deaths_direct").cast("int")) \
           .withColumn("deaths_indirect_int", col("deaths_indirect").cast("int")) \
           .withColumn("begin_date_time", col("begin_date_time").cast("string")) \
           .withColumn("end_date_time", col("end_date_time").cast("string"))

    # Total number of lightning strikes
    total_lightning_strikes = df.filter(df["event_narrative"].contains("lightning")).count()

    # Total number of fatalities
    total_fatalities = df.filter((df["deaths_direct_int"] > 0) | (df["deaths_indirect_int"] > 0)).count()

    # Total number of fires caused by lightning
    fires_by_lightning = df.filter((df["event_narrative"].contains("lightning")) & (df["event_narrative"].contains("fire"))).count()

    return total_lightning_strikes, total_fatalities, fires_by_lightning

# Process the 'real' table
real_totals = process_table(REAL_TABLE_NAME)

# Process the 'fake' table
fake_totals = process_table(FAKE_TABLE_NAME)

# Calculate the combined totals
combined_totals = {
    "Total Lightning Strikes": real_totals[0] + fake_totals[0],
    "Total Fatalities": real_totals[1] + fake_totals[1],
    "Total Fires Caused by Lightning": real_totals[2] + fake_totals[2]
}

# Print the combined totals
for metric, count in combined_totals.items():
    print(f"{metric}: {count}")

# Create a DataFrame to store the combined counts
schema = StructType([
    StructField("metric", StringType(), False),
    StructField("count", IntegerType(), False)
])

data = [(metric, count) for metric, count in combined_totals.items()]

summary_df = spark.createDataFrame(data, schema)

# Convert summary DataFrame to DynamicFrame
dyf_summary = DynamicFrame.fromDF(summary_df, glueContext, "dyf_summary")

# Write the summary data back to S3
output_path = f"s3://wa3548-{ACCOUNT_ID}-glue-job/transformed/"
glueContext.write_dynamic_frame.from_options(frame=dyf_summary, connection_type="s3", connection_options={"path": output_path}, format="parquet")

job.commit()

