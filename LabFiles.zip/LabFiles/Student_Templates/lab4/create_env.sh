#pyenv install 3.11.4 #Now pre-installed
pyenv local 3.11.4
pyenv virtualenv 3.11.4 storm_data_glue
pyenv activate storm_data_glue
pip install pyspark
export AWS_PROFILE=wa3548