from pyspark.sql import SparkSession

# Initialize Spark session
spark = SparkSession.builder \
    .appName("Read Parquet Files") \
    .getOrCreate()

# Define the local path to the Parquet files
parquet_path = "./parquet_files/"

# Read Parquet files without an explicit schema to inspect the schema
df = spark.read.parquet(parquet_path)

# Show the inferred schema
df.printSchema()

# Show a few rows of the DataFrame
df.show()
