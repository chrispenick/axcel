import boto3

def get_account_id():
    sts_client = boto3.client('sts')
    return sts_client.get_caller_identity().get('Account')

def delete_s3_bucket(bucket_name):
    s3_client = boto3.client('s3')
    try:
        # List and delete all objects in the bucket
        response = s3_client.list_objects_v2(Bucket=bucket_name)
        if 'Contents' in response:
            for obj in response['Contents']:
                s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
        
        # List and delete all object versions (if versioning is enabled)
        response = s3_client.list_object_versions(Bucket=bucket_name)
        if 'Versions' in response:
            for version in response['Versions']:
                s3_client.delete_object(Bucket=bucket_name, Key=version['Key'], VersionId=version['VersionId'])
        if 'DeleteMarkers' in response:
            for marker in response['DeleteMarkers']:
                s3_client.delete_object(Bucket=bucket_name, Key=marker['Key'], VersionId=marker['VersionId'])

        # Finally, delete the bucket
        s3_client.delete_bucket(Bucket=bucket_name)
        print(f'Bucket "{bucket_name}" deleted successfully.')
    except Exception as e:
        print(f'Error deleting bucket "{bucket_name}": {e}')

if __name__ == "__main__":
    # Retrieve the AWS account ID
    account_id = get_account_id()

    # Constants for bucket names with account ID
    INPUT_BUCKET_NAME = f'wa3548.{account_id}.lab5.input'
    OUTPUT_BUCKET_NAME = f'wa3548.{account_id}.lab5.output'

    # Delete the input bucket
    delete_s3_bucket(INPUT_BUCKET_NAME)

    # Delete the output bucket
    delete_s3_bucket(OUTPUT_BUCKET_NAME)
