#!/bin/bash

# Define the bucket name based on the AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
INPUT_BUCKET_NAME="wa3548.${ACCOUNT_ID}.lab5.input"

# List the contents of the input bucket
echo "Listing contents of bucket: $INPUT_BUCKET_NAME"
aws s3 ls "s3://${INPUT_BUCKET_NAME}/"
