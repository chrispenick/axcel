# Setup
#pyenv install 3.9.17 # Now preinstalled
pyenv local 3.9.17
pyenv virtualenv 3.9.17 wa3548_lab5
pyenv activate wa3548_lab5
pip install boto3 
export AWS_PROFILE=wa3548
