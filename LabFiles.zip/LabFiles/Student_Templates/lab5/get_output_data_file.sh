#!/bin/bash
# Bucket name
# Define the bucket name based on the AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
OUPUT_BUCKET_NAME="wa3548.${ACCOUNT_ID}.lab5.output"

# List contents of the bucket
echo "Listing contents of bucket: $OUPUT_BUCKET_NAME"
aws s3 ls s3://$OUPUT_BUCKET_NAME/

# Filter for specific file (output_data.json)
echo "Filtering for specific file (output_data.json)"
aws s3 ls s3://$OUPUT_BUCKET_NAME/ --recursive | grep output_data.json

# Download the specific file (output_data.json)
echo "Downloading the file: output_data.json"
aws s3 cp s3://$OUPUT_BUCKET_NAME/output_data.json ./output_data.json

if [ $? -eq 0 ]; then
    echo "File downloaded successfully: output_data.json"
else
    echo "Failed to download the file: output_data.json"
    exit 1
fi