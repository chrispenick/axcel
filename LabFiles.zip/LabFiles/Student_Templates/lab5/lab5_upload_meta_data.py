import boto3
import os

# File paths to be uploaded
METADATA_FILE = 'meta_data.json'
    
def get_account_id():
    sts_client = boto3.client('sts')
    return sts_client.get_caller_identity().get('Account')

def upload_file_to_s3(bucket_name, file_name, object_name=None):
    s3_client = boto3.client('s3')
    try:
        if object_name is None:
            object_name = os.path.basename(file_name)
        s3_client.upload_file(file_name, bucket_name, object_name)
        print(f'File "{file_name}" uploaded to "{bucket_name}/{object_name}".')
    except Exception as e:
        print(f'Error uploading file "{file_name}": {e}')

if __name__ == "__main__":
    # Retrieve the AWS account ID
    account_id = get_account_id()
    print(f'account_id "{account_id}"')
    # Constants for bucket names with account ID
    input_bucket_name = f'wa3548.{account_id}.lab5.input'
    print(f'input_bucket_name "{input_bucket_name}"')
    
    if not os.path.isfile(METADATA_FILE):
        print(f'File {METADATA_FILE} does not exist.')
        exit(1)

    # Upload files to the input bucket
    upload_file_to_s3(input_bucket_name, METADATA_FILE)