import boto3
def get_account_id():
    sts_client = boto3.client('sts')
    return sts_client.get_caller_identity().get('Account')

def create_s3_bucket(bucket_name, region=None):
    try:
        if region is None:
            print("The constant: REGION must be set!" )
        else:
            s3_client = boto3.client('s3', region_name=region)
            location = {'LocationConstraint': region}
            s3_client.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=location)
        print(f'Bucket "{bucket_name}" created successfully.')
    except Exception as e:
        print(f'Error creating bucket "{bucket_name}": {e}')

if __name__ == "__main__":
    # Retrieve the AWS account ID
    account_id = get_account_id()

    # Constants for bucket names with account ID
    INPUT_BUCKET_NAME = f'wa3548.{account_id}.lab5.input'
    OUTPUT_BUCKET_NAME = f'wa3548.{account_id}.lab5.output'
    REGION = 'us-west-2'  # Change the region if needed, by default we use Oregon

    # Create the input bucket
    create_s3_bucket(INPUT_BUCKET_NAME, REGION)

    # Create the output bucket
    create_s3_bucket(OUTPUT_BUCKET_NAME, REGION)