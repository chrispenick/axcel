pyenv wa3548_lab5
export AWS_PROFILE=wa3548
