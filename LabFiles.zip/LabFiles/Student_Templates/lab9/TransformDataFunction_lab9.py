# TransformDataFunction_Lab9.py
# This function gets data from input file in the same bucket and transforms, then saves it.
# Do not remove comments!
import json
import boto3
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Create S3 client
s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Log the received event
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Extract details from the event
    input_key = event.get('input_key')
    output_bucket = event.get('output_bucket')
    output_key = event.get('output_key')

    # Check for required parameters
    if not input_key:
        logger.error("Missing 'input_bucket' or 'input_key' in event")
        raise Exception("Error: 'input_bucket' or 'input_key' missing in event")
        
    if not output_bucket or not output_key:
        logger.error("Missing 'output_bucket' or 'output_key' in event")
        raise Exception("Error: 'output_bucket' or 'output_key' missing in event")
    
    logger.info(f"input_key: {input_key}")
    logger.info(f"output_bucket: {output_bucket}")
    logger.info(f"output_key: {output_key}")


    
    try:
        # Get the "input" object from the output bucket
        response = s3.get_object(Bucket=output_bucket, Key=input_key)
        data = response['Body'].read().decode('utf-8')
        
        # Transform the data
        transformed_data = data.upper()  # Example transformation: convert to uppercase
        
        # Save the transformed data back to S3 with a different key
        transformed_key = output_key
        logger.info(f"transformed_key: {transformed_key}")
        s3.put_object(Bucket=output_bucket, Key=transformed_key, Body=transformed_data)
        logger.info(f"Data transformed and saved to {output_bucket}/{transformed_key}")
        
        body=f"Data transformed from input: {output_bucket}/{input_key} and saved to output: {output_bucket}/{transformed_key} successfully!"
        return {
            'statusCode': 200,
            'body': json.dumps(body)
        }
    
    except Exception as e:
        logger.error(f"[TRANSFORM] Unexpected error: {e}")
        raise Exception("Error: An unexpected error occurred during transformation.")
