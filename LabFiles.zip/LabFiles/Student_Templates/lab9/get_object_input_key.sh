#!/bin/bash
export AWS_PROFILE=wa3548
ACCOUNT_ID="ACCOUNT_ID"
BUCKET="wa3548-${ACCOUNT_ID}-sf-output"
KEY="data/"
REMOTE_FILE="input_data.csv"
LOCAL_FILE="downloaded_output_data.csv"
REGION="eu-west-2"
aws s3api get-object --regio ${REGION} --bucket ${BUCKET} --key ${KEY}${REMOTE_FILE} ${LOCAL_FILE}
