#!/bin/bash
ACCOUNT_ID="ACCOUNT_ID"
OUTPUT_BUCKET="wa3548-${ACCOUNT_ID}-sf-output"
aws s3 ls s3://${OUTPUT_BUCKET}/data/
aws s3 ls s3://${OUTPUT_BUCKET}/transformed/
aws s3api get-object --bucket ${OUTPUT_BUCKET} --key transformed/transformed_data.csv /tmp/transformed_data.csv
