#!/bin/bash
ACCOUNT_ID="ACCOUNT_ID" #replace ACCOUNT_ID
INPUT_BUCKET="wa3548-${ACCOUNT_ID}-sf-input"
aws s3 ls s3://${INPUT_BUCKET}/data/
aws s3 ls s3://${INPUT_BUCKET}/data/input_data.csv
aws s3api get-object --bucket ${INPUT_BUCKET} --key data/input_data.csv /tmp/input_data.csv